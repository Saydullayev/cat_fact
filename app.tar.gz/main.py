import flet as ft
import requests
def main(page: ft.Page):
    page.window_height = 720
    page.window_width = 480
    page.title = "Cat fact"
    page.bgcolor = 'black'
    f = requests.get('https://catfact.ninja/fact').json()
    fact = ft.Text(value = f['fact'], color='white')
    def mer(e):
        fact.value = requests.get('https://catfact.ninja/fact').json()['fact']
        page.update()
    page.add(
        fact,
        ft.IconButton(ft.icons.ADD, on_click=mer, bgcolor='white'),
    )
    page.update()

ft.app(target=main, view='WEB')